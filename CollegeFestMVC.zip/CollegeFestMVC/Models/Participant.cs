using System.ComponentModel.DataAnnotations;

namespace TechnicalFestRegistration.Models;

public class Participant
{
    public int ParticipantId { get; set; }

    [Required(ErrorMessage = "Participant name is required.")]
    public string ParticipantName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Email is required.")]
    [EmailAddress(ErrorMessage = "Enter a valid email address.")]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Department is required.")]
    public string Department { get; set; } = string.Empty;

    [Range(1, 4, ErrorMessage = "Select a valid year.")]
    public int Year { get; set; }

    [Required(ErrorMessage = "Event name is required.")]
    public string EventName { get; set; } = string.Empty;

    public bool IsTeamEvent { get; set; }

    // Nullable property
    public bool? IsRegistrationCompleted { get; set; }
}
