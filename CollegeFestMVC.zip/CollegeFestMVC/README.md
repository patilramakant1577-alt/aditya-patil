# CollegeFestMVC

## Run
```bash
dotnet restore
dotnet run
```

Open:
- HTTP: http://localhost:5000
- HTTPS: https://localhost:5001

## Assignment Features
- ASP.NET Core MVC
- Participant and Event models
- Bootstrap registration form
- Validation
- FestController
- Temporary List<Participant> storage
- Razor conditional Bootstrap alerts
- Extension methods
- GlobalUsings.cs
- Details and Welcome pages
- Tag Helpers
