// Global namespaces available throughout the application
global using TechnicalFestRegistration.Models;
global using TechnicalFestRegistration.Extensions;
global using Microsoft.AspNetCore.Mvc;
