namespace TechnicalFestRegistration.Extensions;

public static class ParticipantExtensions
{
    public static string GetRegistrationStatus(this Participant participant)
    {
        return participant.IsRegistrationCompleted == true
            ? "Confirmed"
            : "Pending";
    }

    public static string GetFeeCategory(this Participant participant)
    {
        decimal fee = participant.GetRegistrationFee();

        if (fee == 0)
            return "Free Event";
        if (fee <= 100)
            return "Standard Event";

        return "Premium Event";
    }

    public static decimal GetRegistrationFee(this Participant participant)
    {
        return participant.EventName switch
        {
            "Web Design" => 0,
            "Coding Competition" => 100,
            "AI Workshop" => 250,
            "Hackathon" => 150,
            _ => 100
        };
    }
}
