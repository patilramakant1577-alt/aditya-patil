namespace TechnicalFestRegistration.Controllers;

public class FestController : Controller
{
    private static readonly List<Participant> participants = new();

    public IActionResult Index()
    {
        return View(participants);
    }

    [HttpGet]
    public IActionResult Register()
    {
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Register(Participant participant)
    {
        if (!ModelState.IsValid)
            return View(participant);

        participant.ParticipantId = participants.Count + 1;

        // Demonstrates confirmed registration.
        participant.IsRegistrationCompleted = true;

        participants.Add(participant);

        TempData["SuccessMessage"] = "Participant registered successfully!";
        return RedirectToAction(nameof(Index));
    }

    public IActionResult Details(int id)
    {
        var participant = participants.FirstOrDefault(p => p.ParticipantId == id);

        if (participant == null)
            return NotFound();

        return View(participant);
    }

    public IActionResult Welcome()
    {
        return View();
    }
}
